package me.yang.luckyneko;

import java.awt.*;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

public class WelcomePanel extends FancyPanel {
    private final long firstRenderingTime;
    private final List<FancyLabel> labels;

    public WelcomePanel(MainPanel parent) {
        super(parent);
        this.labels = new ArrayList<>();

        int i = ZonedDateTime.now().getHour();
        String str;
        if (i <= 4 || i == 23) {
            str = "不要熬夜哦。";
        } else if (i <= 6) {
            str = "你来的真早。";
        } else if (i <= 9) {
            str = "早上好。";
        } else if (i <= 11) {
            str = "上午好。";
        } else if (i <= 14) {
            str = "中午好。";
        } else if (i <= 17) {
            str = "下午好。";
        } else {
            str = "晚上好。";
        }
        FancyLabel welcomeLabel = new FancyLabel(str);
        welcomeLabel.setFont(welcomeLabel.getFont().deriveFont(30.0F));
        welcomeLabel.setBounds(30, 20, 500, 40);
        this.labels.add(welcomeLabel);

        FancyLabel descriptionLabel = new FancyLabel("今天也要努力地抽奖呢！");
        descriptionLabel.setFont(descriptionLabel.getFont().deriveFont(18.0F));
        descriptionLabel.setBounds(30, 75, 500, 26);
        this.labels.add(descriptionLabel);

        FancyButton button = new FancyButton("开抽！");
        button.setBounds(30, 120, 122, 35);
        button.addActionListener(e -> this.parent.switchPanel(this.parent.lotteryPanel));
        this.add(button);

        this.labels.forEach(this::add);
        this.firstRenderingTime = System.nanoTime();
    }

    @Override
    protected void paintComponent(Graphics g) {
        long l = System.nanoTime();
//        for (FancyLabel label : this.labels) {
//            double d = 1.0D - LuckyNekoUtil.clamp(-0.005D * label.getY() + (l - this.firstRenderingTime) / 1.0E9D, 0.0D, 1.0D);
//            label.setLocation((int) (30.0D + 150.0D * d * d * d), label.getY());
//            int i = (int) Math.min(255.0D, 280.0D * (1.0D - d));
//            Color color = label.getForeground();
//            label.setForeground(new Color(color.getRed(), color.getGreen(), color.getBlue(), i));
//        }
        super.paintComponent(g);
    }
}
