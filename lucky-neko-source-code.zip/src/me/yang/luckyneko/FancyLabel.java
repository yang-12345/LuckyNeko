package me.yang.luckyneko;

import javax.swing.*;

/**
 * A label with more beautiful looks.
 */
public class FancyLabel extends JLabel {
    public FancyLabel(String text) {
        super(text);
        this.setFont(LuckyNekoUtil.TEXT_FONT);
        this.setForeground(LuckyNekoUtil.TEXT_COLOR);
    }
}
